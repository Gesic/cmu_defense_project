
#include <math.h>

static inline double round(double val)
{
  return floor(val + 0.5);
}
